Use the Shijima app to manage installed mascots.
Manual modifications to this folder may cause problems.